class UsuarioTable < ActiveRecord::Migration
  def self.up
    create_table :usuario do |t|
      t.string :nome
      t.boolean :cancelado
      t.text :observacao
      t.timestamps
    end
  end

  def self.down
    drop_table :usuario
  end
end
