class TesteController < ApplicationController
  def index
  end
end
