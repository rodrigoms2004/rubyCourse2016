# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random, 
# no regular words or you'll be exposed to dictionary attacks.
ActionController::Base.cookie_verifier_secret = '278944c75e19ce8838f2a25b45365c3e69041a315672098f8076d49e41b729c40375074fba3996d9cf4499e70fa96190797f05d7e3eee59e2dc229ce1169954b';
