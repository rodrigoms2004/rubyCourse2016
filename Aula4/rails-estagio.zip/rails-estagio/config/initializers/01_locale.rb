# tell the I18n library where to find your translations
I18n.load_path = Dir[ File.join(RAILS_ROOT, 'config', 'locale', '*.yml') ]

# you can omit this if you're happy with English as a default locale
I18n.default_locale = "pt-BR" 
